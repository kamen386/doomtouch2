build_native.sh puts gzdoom.pk3 (and soundfonts/fm_banks if produced) here.
