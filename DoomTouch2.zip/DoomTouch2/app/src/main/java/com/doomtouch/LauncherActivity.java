package com.doomtouch;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;

/** Pick an IWAD (doom.wad, doom2.wad, freedoom...) via system picker, copy to app storage, start game. */
public class LauncherActivity extends Activity {
    private static final int REQ_IWAD = 1;
    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        status = new TextView(this);
        status.setText("Выберите IWAD (doom2.wad, freedoom2.wad ...)");
        Button pick = new Button(this);
        pick.setText("Выбрать IWAD");
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IWAD);
        });
        root.addView(status);
        root.addView(pick);
        setContentView(root);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req != REQ_IWAD || res != RESULT_OK || data == null) return;
        try {
            File dir = new File(getExternalFilesDir(null), "wads");
            dir.mkdirs();
            Uri uri = data.getData();
            File out = new File(dir, "iwad.wad");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[1 << 16]; int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            Intent g = new Intent(this, GameActivity.class);
            g.putExtra("iwad", out.getAbsolutePath());
            startActivity(g);
        } catch (IOException e) {
            status.setText("Ошибка: " + e.getMessage());
        }
    }
}
