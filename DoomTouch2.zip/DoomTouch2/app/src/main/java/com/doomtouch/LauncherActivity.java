package com.doomtouch;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

/**
 * Launcher in the style of Doom Touch: tabs, logo, Args field, buttons Freedoom / Full / WADs.
 * Shared folder (any file manager):  /DoomTouch2/iwads   main games (doom.wad, doom2.wad, freedoom2.wad ...)
 *                                    /DoomTouch2/mods    mods and extra WAD/PK3 files
 *                                    /DoomTouch2/saves   saves
 */
public class LauncherActivity extends Activity {
    static File root() { return new File(Environment.getExternalStorageDirectory(), "DoomTouch2"); }

    private static final String[] IWAD_EXT = { ".wad", ".pk3", ".ipk3", ".iwad" };
    private static final String[] MOD_EXT = { ".wad", ".pk3", ".pk7", ".zip", ".deh", ".bex", ".ipk3" };
    private static final int BG = 0xFF14141C, PANEL = 0xFF5A5A62, ACCENT = 0xFFB9B9FF;

    private SharedPreferences prefs;
    private int tab = 0;                 // 0 GZDOOM, 1 ОПЦИИ, 2 ПОМОЩЬ
    private EditText argsField;
    private String argsText = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        argsText = prefs.getString("args", "");
    }

    @Override protected void onResume() { super.onResume(); build(); }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) { build(); }

    // ---------------------------------------------------------------- helpers
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } else {
            requestPermissions(new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, 1);
        }
    }

    private boolean ensureAccess() {
        if (hasAccess()) return true;
        new AlertDialog.Builder(this)
            .setMessage("Нужен доступ к файлам, чтобы читать игры и моды из папки DoomTouch2.")
            .setPositiveButton("Разрешить", (d, w) -> requestAccess())
            .setNegativeButton("Отмена", null).show();
        return false;
    }

    private void info(String msg) { new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show(); }

    private List<File> list(File dir, String[] exts) {
        List<File> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            for (String e : exts) if (f.isFile() && n.endsWith(e)) { out.add(f); break; }
        }
        Collections.sort(out);
        return out;
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT).replaceAll("\\.[^.]*$", "").replaceAll("[^a-z0-9]", "_");
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(20); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(PANEL);
        return b;
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); return v;
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src); OutputStream out = new java.io.FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Returns an error text if the file is not usable as a game IWAD, else null. */
    private String checkIwad(File f) {
        if (!f.exists()) return "Файл не найден:\n" + f.getAbsolutePath();
        if (!f.canRead()) return "Файл нельзя прочитать. Проверьте «Доступ ко всем файлам» для приложения:\n" + f.getAbsolutePath();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            int n = in.read(h);
            String hs = n == 4 ? new String(h) : "";
            if (hs.equals("PWAD")) return f.getName() + " — это PWAD (мод/дополнение), а не основная игра.\nВыберите doom.wad, doom2.wad или freedoom2.wad.";
            if (!hs.equals("IWAD") && !hs.startsWith("PK")) return f.getName() + " не похож на WAD или PK3 (возможно, файл повреждён или не докачан).";
            if (f.length() < 100000) return f.getName() + " слишком мал (" + f.length() + " байт) — похоже, файл не докачан.";
        } catch (IOException e) {
            return "Ошибка чтения файла: " + e.getMessage();
        }
        return null;
    }

    // ---------------------------------------------------------------- args history
    private List<String> history() {
        String s = prefs.getString("hist", "");
        List<String> out = new ArrayList<>();
        if (!s.isEmpty()) out.addAll(Arrays.asList(s.split("\n")));
        return out;
    }

    private void pushHistory(String a) {
        if (a.trim().isEmpty()) return;
        List<String> h = history();
        h.remove(a);
        h.add(0, a);
        while (h.size() > 10) h.remove(h.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (String x : h) { if (sb.length() > 0) sb.append('\n'); sb.append(x); }
        prefs.edit().putString("hist", sb.toString()).apply();
    }

    // ---------------------------------------------------------------- UI
    private void build() {
        if (argsField != null) argsText = argsField.getText().toString();
        argsField = null;
        if (hasAccess()) {
            File r = root();
            new File(r, "iwads").mkdirs(); new File(r, "mods").mkdirs(); new File(r, "saves").mkdirs();
        }

        LinearLayout rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(BG);
        rootView.setPadding(dp(16), dp(12), dp(16), dp(10));

        // tab bar
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = { "GZDOOM", "ОПЦИИ", "ПОМОЩЬ" };
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = text(names[i], 16, i == tab ? Color.WHITE : 0xFFAAAAAA);
            t.setPadding(dp(8), dp(8), dp(8), dp(6));
            View line = new View(this);
            line.setBackgroundColor(i == tab ? Color.WHITE : Color.TRANSPARENT);
            cell.addView(t);
            cell.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));
            cell.setOnClickListener(v -> { tab = idx; build(); });
            tabs.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
        }
        rootView.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        if (tab == 0) buildMain(rootView);
        else if (tab == 1) buildOptions(rootView);
        else buildHelp(rootView);
        setContentView(rootView);
    }

    private void buildMain(LinearLayout rootView) {
        // logo + gear
        FrameLayout logoBox = new FrameLayout(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.gzdoom_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        logoBox.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        ImageView cog = new ImageView(this);
        cog.setImageResource(R.drawable.cog);
        cog.setOnClickListener(v -> { tab = 1; build(); });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END);
        logoBox.addView(cog, cp);
        rootView.addView(logoBox, new LinearLayout.LayoutParams(-1, 0, 1));

        if (!hasAccess()) {
            TextView warn = text("Нет доступа к файлам — нажмите «Разрешить» в ОПЦИЯХ или на любой кнопке ниже.", 13, 0xFFFFB366);
            rootView.addView(warn);
        }

        // mods summary
        Set<String> sel = prefs.getStringSet("mods", new HashSet<String>());
        List<String> names = new ArrayList<>();
        for (String p : sel) if (new File(p).exists()) names.add(new File(p).getName());
        Collections.sort(names);
        TextView modsInfo = text(names.isEmpty() ? "Моды: не выбраны" : "Моды: " + join(names), 13, 0xFFAAAAAA);
        modsInfo.setPadding(0, dp(4), 0, dp(4));
        rootView.addView(modsInfo);

        // Args row
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text("Args:", 18, 0xFFCCCCCC));
        argsField = new EditText(this);
        argsField.setSingleLine(true);
        argsField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        argsField.setTextColor(Color.WHITE);
        argsField.setHintTextColor(0xFF777777);
        argsField.setHint("-skill 4 -warp 1");
        argsField.setText(argsText);
        row.addView(argsField, new LinearLayout.LayoutParams(0, -2, 1));
        ImageButton del = new ImageButton(this);
        del.setImageResource(R.drawable.delete_args); del.setBackgroundColor(Color.TRANSPARENT);
        del.setScaleType(ImageView.ScaleType.FIT_CENTER);
        del.setOnClickListener(v -> argsField.setText(""));
        row.addView(del, new LinearLayout.LayoutParams(dp(44), dp(44)));
        ImageButton hist = new ImageButton(this);
        hist.setImageResource(R.drawable.history); hist.setBackgroundColor(Color.TRANSPARENT);
        hist.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hist.setOnClickListener(v -> showHistory());
        row.addView(hist, new LinearLayout.LayoutParams(dp(44), dp(44)));
        rootView.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        Button free = bigButton("Freedoom"), full = bigButton("Full"), wads = bigButton("WADs");
        free.setOnClickListener(v -> onFreedoom());
        full.setOnClickListener(v -> onFull());
        wads.setOnClickListener(v -> chooseMods());
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, dp(56), 1);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(56), 1.6f);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, dp(56), 1);
        l1.setMargins(0, 0, dp(6), 0); l3.setMargins(dp(6), 0, 0, 0);
        btns.addView(free, l1); btns.addView(full, l2); btns.addView(wads, l3);
        rootView.addView(btns, new LinearLayout.LayoutParams(-1, -2));
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
        return sb.toString();
    }

    private void buildOptions(LinearLayout rootView) {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(12), dp(8), dp(12));
        sv.addView(box);

        box.addView(text("Доступ к файлам: " + (hasAccess() ? "есть" : "НЕТ"), 17, hasAccess() ? 0xFF8CE08C : 0xFFFFB366));
        if (!hasAccess()) {
            Button g = bigButton("Разрешить доступ к файлам");
            g.setOnClickListener(v -> requestAccess());
            box.addView(g, new LinearLayout.LayoutParams(-1, dp(52)));
        }
        TextView path = text("Папка: " + root().getAbsolutePath()
            + "\n  iwads/ — doom.wad, doom2.wad, freedoom2.wad…\n  mods/ — моды и новые WAD/PK3\n  saves/ — сохранения", 14, 0xFFCCCCCC);
        path.setPadding(0, dp(12), 0, dp(12));
        box.addView(path);

        Button resetLayout = bigButton("Сбросить расположение кнопок");
        resetLayout.setOnClickListener(v -> {
            getSharedPreferences("touchlayout", MODE_PRIVATE).edit().clear().apply();
            Toast.makeText(this, "Расположение сброшено", Toast.LENGTH_SHORT).show();
        });
        box.addView(resetLayout, new LinearLayout.LayoutParams(-1, dp(52)));
        Button clearHist = bigButton("Очистить историю Args");
        clearHist.setOnClickListener(v -> {
            prefs.edit().remove("hist").apply();
            Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(8);
        box.addView(clearHist, lp);
        TextView ver = text("GZDoom 4.12.2 • Doom Touch 2", 13, 0xFF888888);
        ver.setPadding(0, dp(16), 0, 0);
        box.addView(ver);
        rootView.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void buildHelp(LinearLayout rootView) {
        ScrollView sv = new ScrollView(this);
        TextView t = text(
            "ЧТО ГДЕ ЛЕЖИТ\n"
          + "• Основная игра (IWAD): doom.wad, doom2.wad, freedoom2.wad — в папку DoomTouch2/iwads.\n"
          + "• Моды, новые уровни (WAD/PK3/ZIP) — в папку DoomTouch2/mods.\n\n"
          + "КНОПКИ\n"
          + "• Freedoom — запустить бесплатную игру Freedoom (файл freedoom2.wad или freedoom1.wad в iwads).\n"
          + "• Full — запустить полную игру (Doom, Doom II, Heretic и т.д.), выбрать из списка.\n"
          + "• WADs — отметить моды, которые нужно подключить.\n"
          + "• Args — дополнительные параметры движка, например: -skill 4 -warp 1.\n\n"
          + "В ИГРЕ\n"
          + "• Левая половина экрана — движение, правая — обзор.\n"
          + "• Шестерёнка вверху — меню: Esc, консоль, изменение расположения кнопок, выход.\n"
          + "• Кнопка с цифрами открывает выбор оружия 1–8, кнопка карты — автокарту с масштабом.",
            16, 0xFFDDDDDD);
        t.setPadding(dp(8), dp(12), dp(8), dp(12));
        sv.addView(t);
        rootView.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    // ---------------------------------------------------------------- actions
    private void showHistory() {
        final List<String> h = history();
        if (h.isEmpty()) { info("История Args пока пуста."); return; }
        new AlertDialog.Builder(this).setTitle("История Args")
            .setItems(h.toArray(new String[0]), (d, which) -> argsField.setText(h.get(which))).show();
    }

    private void onFreedoom() {
        if (!ensureAccess()) return;
        List<File> all = list(new File(root(), "iwads"), IWAD_EXT);
        File pick = null;
        for (File f : all) if (f.getName().equalsIgnoreCase("freedoom2.wad")) pick = f;
        if (pick == null) for (File f : all) if (f.getName().equalsIgnoreCase("freedoom1.wad")) pick = f;
        if (pick == null) for (File f : all) if (f.getName().toLowerCase(Locale.ROOT).contains("freedoom")) pick = f;
        if (pick == null) { info("Freedoom не найден. Скачайте бесплатный freedoom2.wad (freedoom.github.io) и положите в папку DoomTouch2/iwads."); return; }
        launch(pick);
    }

    private void onFull() {
        if (!ensureAccess()) return;
        List<File> all = list(new File(root(), "iwads"), IWAD_EXT);
        final List<File> full = new ArrayList<>();
        for (File f : all) if (!f.getName().toLowerCase(Locale.ROOT).contains("freedoom")) full.add(f);
        if (full.isEmpty()) { info("Полная игра не найдена. Положите doom.wad, doom2.wad и т.п. в папку DoomTouch2/iwads."); return; }
        if (full.size() == 1) { launch(full.get(0)); return; }
        ArrayAdapter<File> ad = new ArrayAdapter<File>(this, 0, full) {
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                LinearLayout r = new LinearLayout(getContext());
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(12), dp(8), dp(12), dp(8));
                File f = getItem(pos);
                ImageView iv = new ImageView(getContext());
                int id = getResources().getIdentifier("cover_" + key(f.getName()), "drawable", getPackageName());
                if (id != 0) iv.setImageResource(id);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                r.addView(iv, new LinearLayout.LayoutParams(dp(110), dp(70)));
                TextView tv = new TextView(getContext());
                tv.setText(f.getName()); tv.setTextSize(18); tv.setPadding(dp(14), 0, 0, 0);
                r.addView(tv);
                return r;
            }
        };
        new AlertDialog.Builder(this).setTitle("Выберите игру").setAdapter(ad, (d, which) -> launch(full.get(which))).show();
    }

    private void chooseMods() {
        if (!ensureAccess()) return;
        final List<File> mods = list(new File(root(), "mods"), MOD_EXT);
        if (mods.isEmpty()) { info("Папка DoomTouch2/mods пуста. Положите туда моды (.wad, .pk3, .zip)."); return; }
        Set<String> cur = prefs.getStringSet("mods", new HashSet<String>());
        final String[] names = new String[mods.size()];
        final boolean[] checked = new boolean[mods.size()];
        for (int i = 0; i < mods.size(); i++) {
            names[i] = mods.get(i).getName();
            checked[i] = cur.contains(mods.get(i).getAbsolutePath());
        }
        new AlertDialog.Builder(this).setTitle("Моды и WAD")
            .setMultiChoiceItems(names, checked, (d, i, c) -> checked[i] = c)
            .setPositiveButton("OK", (d, w) -> {
                Set<String> out = new HashSet<>();
                for (int i = 0; i < mods.size(); i++) if (checked[i]) out.add(mods.get(i).getAbsolutePath());
                prefs.edit().putStringSet("mods", out).apply();
                build();
            })
            .setNegativeButton("Отмена", null).show();
    }

    /** Validates the game file, copies it next to the engine, starts the game. */
    private void launch(final File iwad) {
        if (!ensureAccess()) return;
        String err = checkIwad(iwad);
        if (err != null) { info(err); return; }

        final String argText = argsField != null ? argsField.getText().toString() : argsText;
        argsText = argText;
        prefs.edit().putString("args", argText).putString("iwad", iwad.getAbsolutePath()).apply();
        pushHistory(argText);

        List<String> mods = new ArrayList<>();
        for (String p : prefs.getStringSet("mods", new HashSet<String>())) if (new File(p).exists()) mods.add(p);
        Collections.sort(mods);
        final String[] modArr = mods.toArray(new String[0]);

        // The engine reads the IWAD natively; shared storage can be blocked for native code on some phones,
        // so the game file is copied into the app's own folder first.
        final File dstDir = new File(getExternalFilesDir(null), "wads");
        dstDir.mkdirs();
        final File dst = new File(dstDir, iwad.getName());
        Toast.makeText(this, "Подготовка игры…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String cerr = null;
            try { if (!dst.exists() || dst.length() != iwad.length()) copyFile(iwad, dst); }
            catch (IOException ex) { cerr = String.valueOf(ex.getMessage()); }
            final String ferr = cerr;
            runOnUiThread(() -> {
                if (ferr != null) { info("Не удалось подготовить файл игры: " + ferr); return; }
                Intent g = new Intent(this, GameActivity.class);
                g.putExtra("iwad", dst.getAbsolutePath());
                g.putExtra("mods", modArr);
                g.putExtra("args", argText);
                startActivity(g);
            });
        }).start();
    }
}
