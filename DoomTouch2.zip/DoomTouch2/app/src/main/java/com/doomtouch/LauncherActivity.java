package com.doomtouch;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.*;

/**
 * Launcher. Shared folder (visible in any file manager):  /DoomTouch2/iwads  (doom2.wad, freedoom2.wad ...)
 *                                                          /DoomTouch2/mods   (*.wad *.pk3 *.pk7 *.zip *.deh *.bex)
 *                                                          /DoomTouch2/saves
 */
public class LauncherActivity extends Activity {
    static File root() { return new File(Environment.getExternalStorageDirectory(), "DoomTouch2"); }

    private LinearLayout body;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
    }

    @Override protected void onResume() { super.onResume(); build(); }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) { build(); }

    private TextView label(String t, int sp) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setPadding(0, 16, 0, 8); return v;
    }

    private List<File> list(File dir, String... exts) {
        List<File> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            for (String e : exts) if (f.isFile() && n.endsWith(e)) { out.add(f); break; }
        }
        Collections.sort(out);
        return out;
    }

    private static String header(File f) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[4];
            return in.read(b) == 4 ? new String(b, "ISO-8859-1") : "";
        } catch (Exception e) { return ""; }
    }

    /** Returns an error text if the file is not usable as a game IWAD, else null. */
    private String checkIwad(File f) {
        if (!f.exists()) return "Файл не найден:\n" + f.getAbsolutePath();
        if (!f.canRead()) return "Файл нельзя прочитать. Проверьте «Доступ ко всем файлам» для приложения:\n" + f.getAbsolutePath();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            int n = in.read(h);
            String hs = n == 4 ? new String(h) : "";
            if (hs.equals("PWAD")) return f.getName() + " — это PWAD (мод/дополнение), а не основная игра.\nВыберите doom.wad, doom2.wad или freedoom2.wad.";
            if (!hs.equals("IWAD") && !hs.startsWith("PK")) return f.getName() + " не похож на WAD или PK3 (возможно, файл повреждён или не дозагружен).";
            if (f.length() < 100000) return f.getName() + " слишком мал (" + f.length() + " байт) — похоже, файл не докачан.";
        } catch (java.io.IOException e) {
            return "Ошибка чтения файла: " + e.getMessage();
        }
        return null;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(40, 30, 40, 30);
        sv.addView(body);
        setContentView(sv);

        body.addView(label("Doom Touch 2  •  GZDoom 4.12.2", 22));

        if (!hasAccess()) {
            body.addView(label("Чтобы читать WAD-файлы и моды из папки DoomTouch2, нужен доступ к файлам.", 16));
            Button grant = new Button(this);
            grant.setText("Разрешить доступ к файлам");
            grant.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                } else {
                    requestPermissions(new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, 1);
                }
            });
            body.addView(grant);
            return;
        }

        File root = root();
        File iwadDir = new File(root, "iwads"), modDir = new File(root, "mods");
        iwadDir.mkdirs(); modDir.mkdirs(); new File(root, "saves").mkdirs();
        body.addView(label("Папка: " + root.getAbsolutePath() + "\n  iwads/ — doom.wad, doom2.wad, freedoom2.wad…\n  mods/ — моды и новые WAD/PK3", 14));

        // --- IWAD choice
        body.addView(label("Игра (IWAD)", 18));
        List<File> iwads = list(iwadDir, ".wad", ".pk3", ".ipk3", ".iwad");
        final RadioGroup rg = new RadioGroup(this);
        String lastIwad = prefs.getString("iwad", "");
        for (File f : iwads) {
            RadioButton rb = new RadioButton(this);
            rb.setText(f.getName()); rb.setTag(f.getAbsolutePath()); rb.setId(View.generateViewId());
            rg.addView(rb);
            if (f.getAbsolutePath().equals(lastIwad)) rb.setChecked(true);
        }
        if (iwads.isEmpty()) body.addView(label("Положите IWAD в папку iwads, затем вернитесь сюда.", 14));
        else {
            if (rg.getCheckedRadioButtonId() == -1) ((RadioButton) rg.getChildAt(0)).setChecked(true);
            body.addView(rg);
        }

        // --- mods
        body.addView(label("Моды и WAD (можно несколько)", 18));
        List<File> mods = list(modDir, ".wad", ".pk3", ".pk7", ".zip", ".deh", ".bex", ".ipk3");
        Set<String> lastMods = prefs.getStringSet("mods", new HashSet<>());
        final List<CheckBox> boxes = new ArrayList<>();
        for (File f : mods) {
            CheckBox cb = new CheckBox(this);
            cb.setText(f.getName()); cb.setTag(f.getAbsolutePath());
            cb.setChecked(lastMods.contains(f.getAbsolutePath()));
            boxes.add(cb); body.addView(cb);
        }
        if (mods.isEmpty()) body.addView(label("Папка mods пуста.", 14));

        // --- args
        body.addView(label("Args (доп. параметры, например: -skill 4 -warp 1 +map map01)", 14));
        final EditText args = new EditText(this);
        args.setSingleLine(true); args.setText(prefs.getString("args", ""));
        body.addView(args);

        Button play = new Button(this);
        play.setText("ИГРАТЬ");
        play.setOnClickListener(v -> {
            View c = rg.findViewById(rg.getCheckedRadioButtonId());
            if (c == null) { Toast.makeText(this, "Выберите IWAD", Toast.LENGTH_SHORT).show(); return; }
            String iwad = (String) c.getTag();
            String err = checkIwad(new File(iwad));
            if (err != null) {
                new AlertDialog.Builder(this).setMessage(err).setPositiveButton("OK", null).show();
                return;
            }
            String h = header(new File(iwad));
            if (h.equals("PWAD")) { Toast.makeText(this, "Это не IWAD, а мод (PWAD). Положите его в папку mods.", Toast.LENGTH_LONG).show(); return; }
            if (!h.equals("IWAD") && !h.startsWith("PK")) { Toast.makeText(this, "Файл не читается или не является IWAD: " + new File(iwad).getName(), Toast.LENGTH_LONG).show(); return; }
            ArrayList<String> sel = new ArrayList<>();
            for (CheckBox cb : boxes) if (cb.isChecked()) sel.add((String) cb.getTag());
            prefs.edit().putString("iwad", iwad).putStringSet("mods", new HashSet<>(sel))
                 .putString("args", args.getText().toString()).apply();
            Intent g = new Intent(this, GameActivity.class);
            g.putExtra("iwad", iwad);
            g.putExtra("mods", sel.toArray(new String[0]));
            g.putExtra("args", args.getText().toString());
            startActivity(g);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 30; body.addView(play, lp);
    }
}
