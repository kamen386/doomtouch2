package com.doomtouch;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

/**
 * Launcher in the style of Doom Touch: tabs, logo, Args field, buttons Freedoom / Full / WADs.
 * Shared folder (any file manager):  /DoomTouch2/iwads   main games (doom.wad, doom2.wad, freedoom2.wad ...)
 *                                    /DoomTouch2/mods    mods and extra WAD/PK3 files
 *                                    /DoomTouch2/saves   saves
 */
public class LauncherActivity extends Activity {
    static File root() { return new File(Environment.getExternalStorageDirectory(), "DoomTouch2"); }

    private static final String[] IWAD_EXT = { ".wad", ".pk3", ".ipk3", ".iwad" };
    private static final String[] MOD_EXT = { ".wad", ".pk3", ".pk7", ".zip", ".deh", ".bex", ".ipk3" };
    private static final int BG = 0xFF14141C, PANEL = 0xFF5A5A62, ACCENT = 0xFFB9B9FF;

    private static final String[] BACKENDS = { "OpenGL ES (рекомендуется)", "Программная (SoftPoly)", "OpenGL (как на ПК)" };
    private SharedPreferences prefs;
    private int tab = 0;                 // 0 GZDOOM, 1 ОПЦИИ, 2 ПОМОЩЬ
    private EditText argsField;
    private String argsText = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        argsText = prefs.getString("args", "");
    }

    @Override protected void onResume() { super.onResume(); build(); }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) { build(); }

    // ---------------------------------------------------------------- helpers
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } else {
            requestPermissions(new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, 1);
        }
    }

    private boolean ensureAccess() {
        if (hasAccess()) return true;
        new AlertDialog.Builder(this)
            .setMessage("Нужен доступ к файлам, чтобы читать игры и моды из папки DoomTouch2.")
            .setPositiveButton("Разрешить", (d, w) -> requestAccess())
            .setNegativeButton("Отмена", null).show();
        return false;
    }

    private void info(String msg) { new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show(); }

    private List<File> list(File dir, String[] exts) {
        List<File> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            for (String e : exts) if (f.isFile() && n.endsWith(e)) { out.add(f); break; }
        }
        Collections.sort(out);
        return out;
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT).replaceAll("\\.[^.]*$", "").replaceAll("[^a-z0-9]", "_");
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(20); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(PANEL);
        return b;
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); return v;
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src); OutputStream out = new java.io.FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Returns an error text if the file is not usable as a game IWAD, else null. */
    private String checkIwad(File f) {
        if (!f.exists()) return "Файл не найден:\n" + f.getAbsolutePath();
        if (!f.canRead()) return "Файл нельзя прочитать. Проверьте «Доступ ко всем файлам» для приложения:\n" + f.getAbsolutePath();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            int n = in.read(h);
            String hs = n == 4 ? new String(h) : "";
            if (hs.equals("PWAD")) return f.getName() + " — это PWAD (мод/дополнение), а не основная игра.\nВыберите doom.wad, doom2.wad или freedoom2.wad.";
            if (!hs.equals("IWAD") && !hs.startsWith("PK")) return f.getName() + " не похож на WAD или PK3 (возможно, файл повреждён или не докачан).";
            if (f.length() < 100000) return f.getName() + " слишком мал (" + f.length() + " байт) — похоже, файл не докачан.";
        } catch (IOException e) {
            return "Ошибка чтения файла: " + e.getMessage();
        }
        return null;
    }

    // ---------------------------------------------------------------- args history
    private List<String> history() {
        String s = prefs.getString("hist", "");
        List<String> out = new ArrayList<>();
        if (!s.isEmpty()) out.addAll(Arrays.asList(s.split("\n")));
        return out;
    }

    private void pushHistory(String a) {
        if (a.trim().isEmpty()) return;
        List<String> h = history();
        h.remove(a);
        h.add(0, a);
        while (h.size() > 10) h.remove(h.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (String x : h) { if (sb.length() > 0) sb.append('\n'); sb.append(x); }
        prefs.edit().putString("hist", sb.toString()).apply();
    }

    // ---------------------------------------------------------------- UI
    private void build() {
        if (argsField != null) argsText = argsField.getText().toString();
        argsField = null;
        if (hasAccess()) {
            File r = root();
            new File(r, "iwads").mkdirs(); new File(r, "mods").mkdirs(); new File(r, "saves").mkdirs();
        }

        LinearLayout rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(BG);
        rootView.setPadding(dp(16), dp(12), dp(16), dp(10));

        // tab bar
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = { "GZDOOM", "ОПЦИИ", "ПОМОЩЬ" };
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = text(names[i], 16, i == tab ? Color.WHITE : 0xFFAAAAAA);
            t.setPadding(dp(8), dp(8), dp(8), dp(6));
            View line = new View(this);
            line.setBackgroundColor(i == tab ? Color.WHITE : Color.TRANSPARENT);
            cell.addView(t);
            cell.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));
            cell.setOnClickListener(v -> { tab = idx; build(); });
            tabs.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
        }
        rootView.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        if (tab == 0) buildMain(rootView);
        else if (tab == 1) buildOptions(rootView);
        else buildHelp(rootView);
        setContentView(rootView);
    }

    private void buildMain(LinearLayout rootView) {
        // logo + gear
        FrameLayout logoBox = new FrameLayout(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.gzdoom_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        logoBox.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        ImageView cog = new ImageView(this);
        cog.setImageResource(R.drawable.cog);
        cog.setOnClickListener(v -> { tab = 1; build(); });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END);
        logoBox.addView(cog, cp);
        rootView.addView(logoBox, new LinearLayout.LayoutParams(-1, 0, 1));

        if (!hasAccess()) {
            TextView warn = text("Нет доступа к файлам — нажмите «Разрешить» в ОПЦИЯХ или на любой кнопке ниже.", 13, 0xFFFFB366);
            rootView.addView(warn);
        }

        // mods summary
        Set<String> sel = prefs.getStringSet("mods", new HashSet<String>());
        List<String> names = new ArrayList<>();
        for (String p : sel) if (new File(p).exists()) names.add(new File(p).getName());
        Collections.sort(names);
        TextView modsInfo = text(names.isEmpty() ? "Моды: не выбраны" : "Моды: " + join(names), 13, 0xFFAAAAAA);
        modsInfo.setPadding(0, dp(4), 0, dp(4));
        rootView.addView(modsInfo);

        // Args row
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text("Args:", 18, 0xFFCCCCCC));
        argsField = new EditText(this);
        argsField.setSingleLine(true);
        argsField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        argsField.setTextColor(Color.WHITE);
        argsField.setHintTextColor(0xFF777777);
        argsField.setHint("-skill 4 -warp 1");
        argsField.setText(argsText);
        row.addView(argsField, new LinearLayout.LayoutParams(0, -2, 1));
        ImageButton del = new ImageButton(this);
        del.setImageResource(R.drawable.delete_args); del.setBackgroundColor(Color.TRANSPARENT);
        del.setScaleType(ImageView.ScaleType.FIT_CENTER);
        del.setOnClickListener(v -> argsField.setText(""));
        row.addView(del, new LinearLayout.LayoutParams(dp(44), dp(44)));
        ImageButton hist = new ImageButton(this);
        hist.setImageResource(R.drawable.history); hist.setBackgroundColor(Color.TRANSPARENT);
        hist.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hist.setOnClickListener(v -> showHistory());
        row.addView(hist, new LinearLayout.LayoutParams(dp(44), dp(44)));
        rootView.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        Button free = bigButton("Freedoom"), full = bigButton("Full"), wads = bigButton("WADs");
        free.setOnClickListener(v -> onFreedoom());
        full.setOnClickListener(v -> onFull());
        wads.setOnClickListener(v -> chooseMods());
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, dp(56), 1);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(56), 1.6f);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, dp(56), 1);
        l1.setMargins(0, 0, dp(6), 0); l3.setMargins(dp(6), 0, 0, 0);
        btns.addView(free, l1); btns.addView(full, l2); btns.addView(wads, l3);
        rootView.addView(btns, new LinearLayout.LayoutParams(-1, -2));
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
        return sb.toString();
    }

    private void buildOptions(LinearLayout rootView) {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(12), dp(8), dp(12));
        sv.addView(box);

        box.addView(text("Доступ к файлам: " + (hasAccess() ? "есть" : "НЕТ"), 17, hasAccess() ? 0xFF8CE08C : 0xFFFFB366));
        if (!hasAccess()) {
            Button g = bigButton("Разрешить доступ к файлам");
            g.setOnClickListener(v -> requestAccess());
            box.addView(g, new LinearLayout.LayoutParams(-1, dp(52)));
        }
        TextView path = text("Папка: " + root().getAbsolutePath()
            + "\n  iwads/ — doom.wad, doom2.wad, freedoom2.wad…\n  mods/ — моды и новые WAD/PK3\n  saves/ — сохранения", 14, 0xFFCCCCCC);
        path.setPadding(0, dp(12), 0, dp(12));
        box.addView(path);

        Button resetLayout = bigButton("Сбросить расположение кнопок");
        resetLayout.setOnClickListener(v -> {
            getSharedPreferences("touchlayout", MODE_PRIVATE).edit().clear().apply();
            Toast.makeText(this, "Расположение сброшено", Toast.LENGTH_SHORT).show();
        });
        box.addView(resetLayout, new LinearLayout.LayoutParams(-1, dp(52)));
        Button clearHist = bigButton("Очистить историю Args");
        clearHist.setOnClickListener(v -> {
            prefs.edit().remove("hist").apply();
            Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(8);
        box.addView(clearHist, lp);
        Button gfx = bigButton("Графика: " + BACKENDS[prefs.getInt("backend", 0)]);
        gfx.setOnClickListener(v -> { prefs.edit().putInt("backend", (prefs.getInt("backend", 0) + 1) % 3).apply(); build(); });
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(52));
        gp.topMargin = dp(8);
        box.addView(gfx, gp);
        Button logBtn = bigButton("Лог движка");
        logBtn.setOnClickListener(v -> showEngineLog());
        LinearLayout.LayoutParams lg = new LinearLayout.LayoutParams(-1, dp(52));
        lg.topMargin = dp(8);
        box.addView(logBtn, lg);
        Button diag = bigButton("Диагностика");
        diag.setOnClickListener(v -> diagnostics());
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, dp(52));
        dp2.topMargin = dp(8);
        box.addView(diag, dp2);
        TextView ver = text("GZDoom 4.12.2 • Doom Touch 2", 13, 0xFF888888);
        ver.setPadding(0, dp(16), 0, 0);
        box.addView(ver);
        rootView.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void buildHelp(LinearLayout rootView) {
        ScrollView sv = new ScrollView(this);
        TextView t = text(
            "ЧТО ГДЕ ЛЕЖИТ\n"
          + "• Основная игра (IWAD): doom.wad, doom2.wad, freedoom2.wad — в папку DoomTouch2/iwads.\n"
          + "• Моды, новые уровни (WAD/PK3/ZIP) — в папку DoomTouch2/mods.\n\n"
          + "КНОПКИ\n"
          + "• Freedoom — запустить бесплатную игру Freedoom (файл freedoom2.wad или freedoom1.wad в iwads).\n"
          + "• Full — выбрать основной файл игры (doom.wad, doom2.wad…) в файловом браузере из любой папки и запустить.\n"
          + "• WADs — файловый браузер: отметьте моды (WAD/PK3/ZIP) из любых папок, затем OK.\n"
          + "• Args — дополнительные параметры движка, например: -skill 4 -warp 1.\n\n"
          + "В ИГРЕ\n"
          + "• Левая половина экрана — движение, правая — обзор.\n"
          + "• Шестерёнка вверху — меню: Esc, консоль, изменение расположения кнопок, выход.\n"
          + "• Кнопка с цифрами открывает выбор оружия 1–8, кнопка карты — автокарту с масштабом.",
            16, 0xFFDDDDDD);
        t.setPadding(dp(8), dp(12), dp(8), dp(12));
        sv.addView(t);
        rootView.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    // ---------------------------------------------------------------- actions
    private void showHistory() {
        final List<String> h = history();
        if (h.isEmpty()) { info("История Args пока пуста."); return; }
        new AlertDialog.Builder(this).setTitle("История Args")
            .setItems(h.toArray(new String[0]), (d, which) -> argsField.setText(h.get(which))).show();
    }

    private File lastDir(String k, File def) {
        File d = new File(prefs.getString(k, def.getAbsolutePath()));
        return d.isDirectory() ? d : (def.isDirectory() ? def : Environment.getExternalStorageDirectory());
    }

    private void onFreedoom() {
        if (!ensureAccess()) return;
        List<File> all = new ArrayList<>(list(new File(root(), "iwads"), IWAD_EXT));
        all.addAll(list(lastDir("iwadDir", new File(root(), "iwads")), IWAD_EXT));
        File pick = null;
        for (File f : all) if (f.getName().equalsIgnoreCase("freedoom2.wad")) pick = f;
        if (pick == null) for (File f : all) if (f.getName().equalsIgnoreCase("freedoom1.wad")) pick = f;
        if (pick == null) for (File f : all) if (f.getName().toLowerCase(Locale.ROOT).contains("freedoom")) pick = f;
        if (pick == null) { info("Freedoom не найден. Скачайте бесплатный freedoom2.wad (freedoom.github.io) и положите в папку DoomTouch2/iwads, либо выберите его кнопкой Full."); return; }
        launch(pick);
    }

    /** Full: file browser, pick the main game file (doom.wad, doom2.wad ...) from anywhere. */
    private void onFull() {
        if (!ensureAccess()) return;
        browse("Выберите игру (IWAD)", lastDir("iwadDir", new File(root(), "iwads")), false, IWAD_EXT, null, files -> {
            File f = files.get(0);
            prefs.edit().putString("iwadDir", String.valueOf(f.getParent())).apply();
            launch(f);
        });
    }

    /** WADs: file browser with check marks for mods. */
    private void chooseMods() {
        if (!ensureAccess()) return;
        final Set<String> chosen = new HashSet<>(prefs.getStringSet("mods", new HashSet<String>()));
        browse("Моды и WAD (отметьте файлы)", lastDir("modDir", new File(root(), "mods")), true, MOD_EXT, chosen, files -> {
            if (!files.isEmpty()) prefs.edit().putString("modDir", String.valueOf(files.get(0).getParent())).apply();
            prefs.edit().putStringSet("mods", chosen).apply();
            build();
        });
    }

    private interface PickListener { void onPick(List<File> files); }

    private void browse(String title, File start, final boolean multi, final String[] exts,
                        final Set<String> chosen, final PickListener listener) {
        final File[] cur = { start != null && start.isDirectory() ? start : Environment.getExternalStorageDirectory() };
        final File[] up = { null };
        final File top = Environment.getExternalStorageDirectory();
        final AlertDialog[] dlg = new AlertDialog[1];
        final List<File> items = new ArrayList<>();

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        final TextView pathTv = new TextView(this);
        pathTv.setTextSize(12); pathTv.setPadding(dp(16), dp(6), dp(16), dp(6));
        final ListView lv = new ListView(this);
        box.addView(pathTv);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(260)));

        final ArrayAdapter<File> ad = new ArrayAdapter<File>(this, 0, items) {
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                File f = getItem(pos);
                LinearLayout r = new LinearLayout(getContext());
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(14), dp(8), dp(14), dp(8));
                ImageView iv = new ImageView(getContext());
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                String name = f == up[0] ? ".." : f.getName();
                int cover = 0;
                if (f != up[0] && f.isFile() && !multi)
                    cover = getResources().getIdentifier("cover_" + key(name), "drawable", getPackageName());
                if (f == up[0] || f.isDirectory()) iv.setImageResource(R.drawable.file_folder);
                else if (cover != 0) iv.setImageResource(cover);
                else if (name.toLowerCase(Locale.ROOT).endsWith(".zip") || name.toLowerCase(Locale.ROOT).endsWith(".pk3")
                      || name.toLowerCase(Locale.ROOT).endsWith(".pk7")) iv.setImageResource(R.drawable.file_zip);
                else iv.setImageResource(R.drawable.file_unknown);
                r.addView(iv, new LinearLayout.LayoutParams(cover != 0 ? dp(70) : dp(34), cover != 0 ? dp(44) : dp(34)));
                TextView tv = new TextView(getContext());
                tv.setText(name); tv.setTextSize(16); tv.setPadding(dp(12), 0, 0, 0);
                r.addView(tv, new LinearLayout.LayoutParams(0, -2, 1));
                if (multi && f != up[0] && f.isFile()) {
                    CheckBox cb = new CheckBox(getContext());
                    cb.setChecked(chosen.contains(f.getAbsolutePath()));
                    cb.setClickable(false); cb.setFocusable(false);
                    r.addView(cb);
                }
                return r;
            }
        };
        lv.setAdapter(ad);

        final Runnable refresh = new Runnable() {
            @Override public void run() {
                items.clear();
                File dir = cur[0];
                pathTv.setText(dir.getAbsolutePath());
                List<File> dirs = new ArrayList<>(), files = new ArrayList<>();
                File[] fs = dir.listFiles();
                if (fs != null) for (File f : fs) {
                    String n = f.getName().toLowerCase(Locale.ROOT);
                    if (n.startsWith(".")) continue;
                    if (f.isDirectory()) dirs.add(f);
                    else for (String e : exts) if (n.endsWith(e)) { files.add(f); break; }
                }
                Collections.sort(dirs); Collections.sort(files);
                up[0] = (!dir.equals(top) && dir.getParentFile() != null) ? dir.getParentFile() : null;
                if (up[0] != null) items.add(up[0]);
                items.addAll(dirs); items.addAll(files);
                ad.notifyDataSetChanged();
            }
        };
        refresh.run();

        lv.setOnItemClickListener((parentView, itemView, pos, rowId) -> {
            File f = items.get(pos);
            if (f == up[0] || f.isDirectory()) { cur[0] = f; refresh.run(); return; }
            if (multi) {
                String ap = f.getAbsolutePath();
                if (!chosen.remove(ap)) chosen.add(ap);
                ad.notifyDataSetChanged();
            } else {
                dlg[0].dismiss();
                listener.onPick(Collections.singletonList(f));
            }
        });

        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title).setView(box)
            .setNegativeButton("Отмена", null);
        if (multi) b.setPositiveButton("OK", (d, w) -> {
            List<File> out = new ArrayList<>();
            for (String ap : chosen) out.add(new File(ap));
            listener.onPick(out);
        });
        dlg[0] = b.show();
    }

    private void diagnostics() {
        StringBuilder sb = new StringBuilder();
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Доступ к файлам: ").append(hasAccess() ? "есть" : "НЕТ").append("\n\n");
        sb.append("Папка iwads (").append(new File(root(), "iwads").getAbsolutePath()).append("):\n");
        for (File f : list(new File(root(), "iwads"), IWAD_EXT)) sb.append("  ").append(describe(f)).append("\n");
        File wads = new File(getExternalFilesDir(null), "wads");
        sb.append("\nПапка движка:\n");
        File[] fs = wads.listFiles();
        if (fs == null || fs.length == 0) sb.append("  (пусто)\n");
        else for (File f : fs) sb.append("  ").append(describe(f)).append("\n");
        sb.append("\nПоследняя игра: ").append(prefs.getString("iwad", "—"));
        sb.append("\n\nЛог движка (конец):\n").append(engineLogTail());
        new AlertDialog.Builder(this).setTitle("Диагностика").setMessage(sb.toString())
            .setPositiveButton("OK", null).show();
    }

    private void showEngineLog() {
        File f = new File(getExternalFilesDir(null), "engine.log");
        String body;
        if (!f.exists()) body = "Лога ещё нет — запустите игру.";
        else try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[(int) Math.min(f.length(), 300000)];
            int n = in.read(buf);
            String[] lines = new String(buf, 0, Math.max(n, 0)).split("\n");
            StringBuilder sb = new StringBuilder();
            int head = Math.min(8, lines.length), tailFrom = Math.max(head, lines.length - 45);
            for (int i = 0; i < head; i++) sb.append(lines[i]).append('\n');
            if (tailFrom > head) sb.append("… (пропущено ").append(tailFrom - head).append(" строк) …\n");
            for (int i = tailFrom; i < lines.length; i++) sb.append(lines[i]).append('\n');
            body = sb.toString();
        } catch (IOException e) { body = "Не удалось прочитать лог: " + e.getMessage(); }
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body); tv.setTextSize(11); tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setPadding(dp(14), dp(10), dp(14), dp(10)); tv.setTextIsSelectable(true);
        sv.addView(tv);
        new AlertDialog.Builder(this).setTitle("Лог движка").setView(sv).setPositiveButton("OK", null).show();
    }

    private String engineLogTail() {
        File f = new File(getExternalFilesDir(null), "engine.log");
        if (!f.exists()) return "  (лога ещё нет — запустите игру)";
        try (FileInputStream in = new FileInputStream(f)) {
            long len = f.length();
            long skip = Math.max(0, len - 3000);
            in.skip(skip);
            byte[] buf = new byte[(int) (len - skip)];
            int n = in.read(buf);
            String t = new String(buf, 0, Math.max(n, 0));
            String[] lines = t.split("\n");
            StringBuilder sb = new StringBuilder();
            for (int i = Math.max(0, lines.length - 25); i < lines.length; i++) sb.append("  ").append(lines[i]).append("\n");
            return sb.length() == 0 ? "  (лог пуст)" : sb.toString();
        } catch (IOException e) {
            return "  не удалось прочитать: " + e.getMessage();
        }
    }

    private String describe(File f) {
        String head = "";
        if (f.isFile()) try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4]; int n = in.read(h);
            head = n == 4 ? new String(h).replaceAll("[^ -~]", "?") : "?";
        } catch (IOException e) { head = "не читается"; }
        return f.getName() + " — " + (f.length() / 1024) + " КБ" + (head.isEmpty() ? "" : " [" + head + "]");
    }

    /** Validates the game file, copies game + mods next to the engine, starts the game. */
    private void launch(final File iwad) {
        if (!ensureAccess()) return;
        String err = checkIwad(iwad);
        if (err != null) { info(err); return; }

        final String argText = argsField != null ? argsField.getText().toString() : argsText;
        argsText = argText;
        prefs.edit().putString("args", argText).putString("iwad", iwad.getAbsolutePath()).apply();
        pushHistory(argText);

        final List<File> mods = new ArrayList<>();
        for (String p : prefs.getStringSet("mods", new HashSet<String>())) if (new File(p).exists()) mods.add(new File(p));
        Collections.sort(mods);

        // The engine reads files natively; shared storage can be blocked for native code on some phones,
        // so the game and mods are copied into the app's own folders first (only when missing / changed).
        final File dstDir = new File(getExternalFilesDir(null), "wads");
        final File modDir = new File(getExternalFilesDir(null), "mods");
        dstDir.mkdirs(); modDir.mkdirs();
        final File dst = new File(dstDir, iwad.getName().toLowerCase(Locale.ROOT));
        Toast.makeText(this, "Подготовка игры…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String cerr = null;
            final List<String> modPaths = new ArrayList<>();
            try {
                if (!dst.exists() || dst.length() != iwad.length()) copyFile(iwad, dst);
                for (File m : mods) {
                    File md = new File(modDir, m.getName());
                    if (!md.exists() || md.length() != m.length()) copyFile(m, md);
                    modPaths.add(md.getAbsolutePath());
                }
            } catch (IOException ex) { cerr = String.valueOf(ex.getMessage()); }
            final String ferr = cerr;
            runOnUiThread(() -> {
                if (ferr != null) { info("Не удалось подготовить файлы: " + ferr); return; }
                Intent g = new Intent(this, GameActivity.class);
                g.putExtra("iwad", dst.getAbsolutePath());
                g.putExtra("mods", modPaths.toArray(new String[0]));
                g.putExtra("args", argText);
                g.putExtra("backend", prefs.getInt("backend", 0));
                startActivity(g);
            });
        }).start();
    }
}
