package com.doomtouch;

import android.content.Context;
import android.graphics.*;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import org.libsdl.app.SDLActivity;

/**
 * Left: virtual stick -> W/A/S/D. Right area: drag = look (relative mouse).
 * Buttons: FIRE (Ctrl), USE (Space), weapon next/prev (]/[).
 * GZDoom sees ordinary keyboard + mouse input, so its source stays untouched.
 */
public class TouchOverlay extends View {
    private static final class Btn {
        final String label; final int key; RectF r = new RectF(); int ptr = -1;
        Btn(String l, int k) { label = l; key = k; }
    }
    private final Btn[] btns = {
        new Btn("FIRE", KeyEvent.KEYCODE_CTRL_LEFT), new Btn("USE", KeyEvent.KEYCODE_SPACE),
        new Btn(">", KeyEvent.KEYCODE_RIGHT_BRACKET), new Btn("<", KeyEvent.KEYCODE_LEFT_BRACKET),
    };
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int stickPtr = -1, lookPtr = -1;
    private float sx, sy, cx, cy, lastX, lastY;
    private final boolean[] dir = new boolean[4]; // W A S D
    private static final int[] DIR_KEYS = {
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D };

    public TouchOverlay(Context c) { super(c); p.setTextAlign(Paint.Align.CENTER); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float s = Math.min(w, h) * 0.16f, m = s * 0.3f;
        btns[0].r.set(w - 2 * s - m, h - 2 * s - m, w - m, h - m);               // FIRE
        btns[1].r.set(w - 3.2f * s - m, h - s - m, w - 2.2f * s - m, h - m);      // USE
        btns[2].r.set(w - s - m, h - 3.2f * s - m, w - m, h - 2.2f * s - m);      // next weapon
        btns[3].r.set(w - 2.2f * s - m, h - 3.2f * s - m, w - 1.2f * s - m, h - 2.2f * s - m); // prev
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), idx = e.getActionIndex(), id = e.getPointerId(idx);
        float x = e.getX(idx), y = e.getY(idx);
        switch (a) {
            case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN:
                for (Btn b : btns) if (b.ptr < 0 && b.r.contains(x, y)) {
                    b.ptr = id; SDLActivity.onNativeKeyDown(b.key); invalidate(); return true; }
                if (x < getWidth() / 2f && stickPtr < 0) { stickPtr = id; sx = cx = x; sy = cy = y; }
                else if (x >= getWidth() / 2f && lookPtr < 0) { lookPtr = id; lastX = x; lastY = y; }
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int pid = e.getPointerId(i);
                    if (pid == stickPtr) { cx = e.getX(i); cy = e.getY(i); updateDirs(); }
                    else if (pid == lookPtr) {
                        float nx = e.getX(i), ny = e.getY(i);
                        SDLActivity.onNativeMouse(0, MotionEvent.ACTION_MOVE, (nx - lastX) * 1.5f, (ny - lastY) * 1.5f, true);
                        lastX = nx; lastY = ny;
                    }
                }
                break;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_POINTER_UP: case MotionEvent.ACTION_CANCEL:
                for (Btn b : btns) if (b.ptr == id) { b.ptr = -1; SDLActivity.onNativeKeyUp(b.key); }
                if (id == stickPtr) { stickPtr = -1; cx = sx; cy = sy; updateDirs(); }
                if (id == lookPtr) lookPtr = -1;
                break;
        }
        invalidate();
        return true;
    }

    private void updateDirs() {
        float dz = Math.min(getWidth(), getHeight()) * 0.04f, dx = cx - sx, dy = cy - sy;
        boolean[] n = { dy < -dz, dx < -dz, dy > dz, dx > dz };
        for (int i = 0; i < 4; i++) if (n[i] != dir[i]) {
            dir[i] = n[i];
            if (n[i]) SDLActivity.onNativeKeyDown(DIR_KEYS[i]); else SDLActivity.onNativeKeyUp(DIR_KEYS[i]);
        }
    }

    @Override protected void onDraw(Canvas c) {
        p.setStyle(Paint.Style.FILL); p.setTextSize(getHeight() * 0.04f);
        for (Btn b : btns) {
            p.setColor(b.ptr >= 0 ? 0x88FFFFFF : 0x44FFFFFF);
            c.drawRoundRect(b.r, 24, 24, p);
            p.setColor(0xCCFFFFFF);
            c.drawText(b.label, b.r.centerX(), b.r.centerY() + p.getTextSize() / 3, p);
        }
        if (stickPtr >= 0) {
            p.setColor(0x33FFFFFF); c.drawCircle(sx, sy, getHeight() * 0.12f, p);
            p.setColor(0x88FFFFFF); c.drawCircle(cx, cy, getHeight() * 0.05f, p);
        }
    }
}
