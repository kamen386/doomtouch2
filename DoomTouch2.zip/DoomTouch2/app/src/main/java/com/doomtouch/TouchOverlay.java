package com.doomtouch;

import android.content.Context;
import android.graphics.*;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import org.libsdl.app.SDLActivity;

/**
 * Touch interface using the original Doom Touch icons.
 * Left half: floating stick (WASD). Right half drag: look (relative mouse).
 * Buttons: FIRE, USE, JUMP, CROUCH, prev/next weapon, MAP, MENU.
 * GZDoom only sees keyboard + mouse events, so the engine itself stays untouched.
 * Key binds for X/C/Z/V come from touch.cfg written by GameActivity.
 */
public class TouchOverlay extends View {
    private static final class Btn {
        final int res; final int key; final float cx, cy, d; // cx,cy,d as fractions of height / width
        Bitmap bmp; RectF r = new RectF(); int ptr = -1;
        Btn(int res, int key, float cx, float cy, float d) { this.res = res; this.key = key; this.cx = cx; this.cy = cy; this.d = d; }
    }
    private Btn[] btns;
    private Bitmap stickBase, stickKnob;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private int stickPtr = -1, lookPtr = -1;
    private float sx, sy, cx, cy, lastX, lastY;
    private final boolean[] dir = new boolean[4]; // W A S D
    private static final int[] DIR_KEYS = {
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D };

    public TouchOverlay(Context c) {
        super(c);
        stickBase = BitmapFactory.decodeResource(getResources(), R.drawable.strafe_arrow);
        stickKnob = BitmapFactory.decodeResource(getResources(), R.drawable.look_arrow);
        // positions: cx from right edge (fraction of height), cy from bottom (fraction of height), d = diameter (fraction of height)
        btns = new Btn[] {
            new Btn(R.drawable.shoot,     KeyEvent.KEYCODE_CTRL_LEFT,  0.20f, 0.21f, 0.30f), // FIRE
            new Btn(R.drawable.use,       KeyEvent.KEYCODE_SPACE,      0.46f, 0.14f, 0.20f), // USE
            new Btn(R.drawable.jump,      KeyEvent.KEYCODE_X,          0.09f, 0.47f, 0.17f), // JUMP
            new Btn(R.drawable.crouch,    KeyEvent.KEYCODE_C,          0.29f, 0.47f, 0.17f), // CROUCH
            new Btn(R.drawable.next_weap, KeyEvent.KEYCODE_V,          0.08f, 0.70f, 0.13f), // next weapon
            new Btn(R.drawable.prev_weap, KeyEvent.KEYCODE_Z,          0.24f, 0.70f, 0.13f), // prev weapon
            new Btn(R.drawable.map,       KeyEvent.KEYCODE_TAB,        0.08f, 0.91f, 0.11f), // MAP
            new Btn(R.drawable.settings,  KeyEvent.KEYCODE_ESCAPE,     0.24f, 0.91f, 0.11f), // MENU
        };
        for (Btn b : btns) b.bmp = BitmapFactory.decodeResource(getResources(), b.res);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        for (Btn b : btns) {
            float d = b.d * h, x = w - b.cx * h, y = h - b.cy * h;
            b.r.set(x - d / 2, y - d / 2, x + d / 2, y + d / 2);
        }
        sx = cx = 0.30f * h; sy = cy = 0.72f * h;   // default (idle) stick position
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), idx = e.getActionIndex(), id = e.getPointerId(idx);
        float x = e.getX(idx), y = e.getY(idx);
        switch (a) {
            case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN:
                for (Btn b : btns) if (b.ptr < 0 && b.r.contains(x, y)) {
                    b.ptr = id; SDLActivity.onNativeKeyDown(b.key); invalidate(); return true; }
                if (x < getWidth() / 2f && stickPtr < 0) { stickPtr = id; sx = cx = x; sy = cy = y; }
                else if (x >= getWidth() / 2f && lookPtr < 0) { lookPtr = id; lastX = x; lastY = y; }
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int pid = e.getPointerId(i);
                    if (pid == stickPtr) { cx = e.getX(i); cy = e.getY(i); updateDirs(); }
                    else if (pid == lookPtr) {
                        float nx = e.getX(i), ny = e.getY(i);
                        SDLActivity.onNativeMouse(0, MotionEvent.ACTION_MOVE, (nx - lastX) * 1.5f, (ny - lastY) * 1.5f, true);
                        lastX = nx; lastY = ny;
                    }
                }
                break;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_POINTER_UP: case MotionEvent.ACTION_CANCEL:
                for (Btn b : btns) if (b.ptr == id) { b.ptr = -1; SDLActivity.onNativeKeyUp(b.key); }
                if (id == stickPtr) { stickPtr = -1; cx = sx = 0.30f * getHeight(); cy = sy = 0.72f * getHeight(); updateDirs(); }
                if (id == lookPtr) lookPtr = -1;
                break;
        }
        invalidate();
        return true;
    }

    private void updateDirs() {
        float dz = getHeight() * 0.04f, dx = cx - sx, dy = cy - sy;
        boolean[] n = { dy < -dz, dx < -dz, dy > dz, dx > dz };
        for (int i = 0; i < 4; i++) if (n[i] != dir[i]) {
            dir[i] = n[i];
            if (n[i]) SDLActivity.onNativeKeyDown(DIR_KEYS[i]); else SDLActivity.onNativeKeyUp(DIR_KEYS[i]);
        }
    }

    @Override protected void onDraw(Canvas c) {
        for (Btn b : btns) {
            p.setAlpha(b.ptr >= 0 ? 255 : 150);
            c.drawBitmap(b.bmp, null, b.r, p);
        }
        float base = getHeight() * 0.36f, knob = getHeight() * 0.16f;
        float kx = cx, ky = cy;
        float max = base * 0.4f, dx = kx - sx, dy = ky - sy, len = (float) Math.hypot(dx, dy);
        if (len > max) { kx = sx + dx / len * max; ky = sy + dy / len * max; }
        p.setAlpha(stickPtr >= 0 ? 200 : 90);
        c.drawBitmap(stickBase, null, new RectF(sx - base / 2, sy - base / 2, sx + base / 2, sy + base / 2), p);
        p.setAlpha(stickPtr >= 0 ? 255 : 120);
        c.drawBitmap(stickKnob, null, new RectF(kx - knob / 2, ky - knob / 2, kx + knob / 2, ky + knob / 2), p);
    }
}
