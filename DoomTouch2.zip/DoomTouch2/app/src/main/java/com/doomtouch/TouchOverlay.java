package com.doomtouch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import java.util.ArrayList;
import java.util.List;
import org.libsdl.app.SDLActivity;

/**
 * Touch interface with the original Doom Touch icons.
 * Stick (left half) = WASD, drag on the right half = look, buttons = keys GZDoom already understands,
 * so the engine itself stays untouched. Button positions/sizes can be edited (gear -> "Изменить расположение").
 */
public class TouchOverlay extends View {
    private enum G { GAME, TOP, WEAPONS, MAPZOOM, MENU }
    private static final int A_NONE = 0, A_GEAR = 1, A_MAP = 2, A_WEAPONS = 3, A_KB = 4, A_MENUOFF = 5;

    private static final class Btn {
        final String id; final int res, key, act; final G g; final float rx, by, d;
        Bitmap bmp; final RectF r = new RectF(); int ptr = -1; float fx, fy, fd;
        Btn(String id, int res, int key, int act, G g, float rx, float by, float d) {
            this.id = id; this.res = res; this.key = key; this.act = act; this.g = g; this.rx = rx; this.by = by; this.d = d;
        }
    }

    private final List<Btn> btns = new ArrayList<>();
    private final SharedPreferences prefs;
    private final Bitmap stickBase, stickKnob;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int stickPtr = -1, lookPtr = -1;
    private float sx, sy, cx, cy, lastX, lastY;
    private final boolean[] dir = new boolean[4]; // W A S D
    private static final int[] DIR_KEYS = {
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D };
    private boolean weaponsOn, mapOn, menuMode, edit;
    private Btn selected, dragging;
    private float dragDx, dragDy;
    private final RectF[] panel = { new RectF(), new RectF(), new RectF(), new RectF() };
    private static final String[] PANEL_TXT = { "−", "+", "Сброс", "Готово" };

    public TouchOverlay(Context c) {
        super(c);
        prefs = c.getSharedPreferences("touchlayout", Context.MODE_PRIVATE);
        stickBase = bmp(R.drawable.strafe_arrow);
        stickKnob = bmp(R.drawable.look_arrow);
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(3);

        // id, icon, key, action, group, distance from right edge (x height), distance from bottom (x height), diameter (x height)
        add("fire",   R.drawable.shoot,        KeyEvent.KEYCODE_CTRL_LEFT, A_NONE, G.GAME, 0.20f, 0.21f, 0.30f);
        add("use",    R.drawable.use,          KeyEvent.KEYCODE_SPACE,     A_NONE, G.GAME, 0.46f, 0.14f, 0.20f);
        add("jump",   R.drawable.jump,         KeyEvent.KEYCODE_X,         A_NONE, G.GAME, 0.09f, 0.47f, 0.17f);
        add("crouch", R.drawable.crouch,       KeyEvent.KEYCODE_C,         A_NONE, G.GAME, 0.29f, 0.47f, 0.17f);
        add("nextw",  R.drawable.next_weap,    KeyEvent.KEYCODE_V,         A_NONE, G.GAME, 0.08f, 0.70f, 0.13f);
        add("prevw",  R.drawable.prev_weap,    KeyEvent.KEYCODE_Z,         A_NONE, G.GAME, 0.24f, 0.70f, 0.13f);

        add("gear",   R.drawable.settings,     0,                          A_GEAR,    G.TOP, 0.08f, 0.91f, 0.11f);
        add("map",    R.drawable.map,          0,                          A_MAP,     G.TOP, 0.24f, 0.91f, 0.11f);
        add("inv",    R.drawable.inv,          KeyEvent.KEYCODE_ENTER,     A_NONE,    G.TOP, 0.40f, 0.91f, 0.11f);
        add("wlist",  R.drawable.show_weapons, 0,                          A_WEAPONS, G.TOP, 0.56f, 0.91f, 0.11f);
        add("kbd",    R.drawable.keyboard,     0,                          A_KB,      G.TOP, 0.72f, 0.91f, 0.12f);
        add("gamma",  R.drawable.gamma,        KeyEvent.KEYCODE_F11,       A_NONE,    G.TOP, 0.88f, 0.91f, 0.11f);
        add("save",   R.drawable.save,         KeyEvent.KEYCODE_F6,        A_NONE,    G.TOP, 1.04f, 0.91f, 0.11f);
        add("load",   R.drawable.load,         KeyEvent.KEYCODE_F9,        A_NONE,    G.TOP, 1.20f, 0.91f, 0.11f);

        int[] nums = { R.drawable.key_1, R.drawable.key_2, R.drawable.key_3, R.drawable.key_4,
                       R.drawable.key_5, R.drawable.key_6, R.drawable.key_7, R.drawable.key_8 };
        for (int i = 0; i < 8; i++)
            add("w" + (i + 1), nums[i], KeyEvent.KEYCODE_1 + i, A_NONE, G.WEAPONS, 0.40f + i * 0.14f, 0.76f, 0.12f);

        add("zin",    R.drawable.key_plus,     KeyEvent.KEYCODE_EQUALS,    A_NONE, G.MAPZOOM, 0.08f, 0.81f, 0.09f);
        add("zout",   R.drawable.key_minus,    KeyEvent.KEYCODE_MINUS,     A_NONE, G.MAPZOOM, 0.20f, 0.81f, 0.09f);

        add("m_up",   R.drawable.arrow_up,     KeyEvent.KEYCODE_DPAD_UP,    A_NONE, G.MENU, 0.28f, 0.58f, 0.14f);
        add("m_down", R.drawable.arrow_down,   KeyEvent.KEYCODE_DPAD_DOWN,  A_NONE, G.MENU, 0.28f, 0.30f, 0.14f);
        add("m_left", R.drawable.arrow_left,   KeyEvent.KEYCODE_DPAD_LEFT,  A_NONE, G.MENU, 0.46f, 0.44f, 0.14f);
        add("m_right",R.drawable.arrow_right,  KeyEvent.KEYCODE_DPAD_RIGHT, A_NONE, G.MENU, 0.10f, 0.44f, 0.14f);
        add("m_enter",R.drawable.enter,        KeyEvent.KEYCODE_ENTER,      A_NONE, G.MENU, 0.72f, 0.30f, 0.20f);
        add("m_back", R.drawable.red_cross,    KeyEvent.KEYCODE_ESCAPE,     A_NONE, G.MENU, 0.08f, 0.91f, 0.11f);
        add("m_off",  R.drawable.settings,     0,                           A_MENUOFF, G.MENU, 0.24f, 0.91f, 0.11f);
    }

    private Bitmap bmp(int res) { return BitmapFactory.decodeResource(getResources(), res); }

    private void add(String id, int res, int key, int act, G g, float rx, float by, float d) {
        Btn b = new Btn(id, res, key, act, g, rx, by, d);
        b.bmp = bmp(res);
        btns.add(b);
    }

    // ---------- layout ----------
    private void defaults(Btn b, int w, int h) { b.fx = (w - b.rx * h) / w; b.fy = (h - b.by * h) / h; b.fd = b.d; }

    private void place(Btn b) {
        int w = getWidth(), h = getHeight();
        float d = b.fd * h, x = b.fx * w, y = b.fy * h;
        b.r.set(x - d / 2, y - d / 2, x + d / 2, y + d / 2);
    }

    private void loadLayout() {
        int w = getWidth(), h = getHeight();
        for (Btn b : btns) {
            defaults(b, w, h);
            String s = prefs.getString("L_" + b.id, null);
            if (s != null) try {
                String[] t = s.split(",");
                b.fx = Float.parseFloat(t[0]); b.fy = Float.parseFloat(t[1]); b.fd = Float.parseFloat(t[2]);
            } catch (Exception ignored) { }
            place(b);
        }
    }

    private void saveLayout() {
        SharedPreferences.Editor e = prefs.edit();
        for (Btn b : btns) e.putString("L_" + b.id, b.fx + "," + b.fy + "," + b.fd);
        e.apply();
    }

    private void resetLayout() {
        prefs.edit().clear().apply();
        loadLayout();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        loadLayout();
        sx = cx = 0.30f * h; sy = cy = 0.72f * h;
        float pw = 0.22f * h, ph = 0.11f * h, gap = 0.02f * h, total = 4 * pw + 3 * gap, x0 = (w - total) / 2, y0 = h - ph - 0.04f * h;
        for (int i = 0; i < 4; i++) panel[i].set(x0 + i * (pw + gap), y0, x0 + i * (pw + gap) + pw, y0 + ph);
    }

    private boolean visible(Btn b) {
        if (edit) return b.g != G.MENU;
        if (menuMode) return b.g == G.MENU;
        switch (b.g) {
            case WEAPONS: return weaponsOn;
            case MAPZOOM: return mapOn;
            case MENU: return false;
            default: return true;
        }
    }

    // ---------- actions ----------
    private void tap(int key) {
        SDLActivity.onNativeKeyDown(key);
        postDelayed(() -> SDLActivity.onNativeKeyUp(key), 60);
    }

    private void action(Btn b) {
        switch (b.act) {
            case A_GEAR: showGearMenu(); break;
            case A_MAP: tap(KeyEvent.KEYCODE_TAB); mapOn = !mapOn; break;
            case A_WEAPONS: weaponsOn = !weaponsOn; break;
            case A_KB: {
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                break;
            }
            case A_MENUOFF: menuMode = false; break;
        }
    }

    private void showGearMenu() {
        String[] items = { "Меню игры (Esc)", "Консоль", "Изменить расположение кнопок", "Сбросить расположение", "Выйти из игры" };
        new AlertDialog.Builder(getContext()).setItems(items, (d, which) -> {
            switch (which) {
                case 0: tap(KeyEvent.KEYCODE_ESCAPE); menuMode = true; break;
                case 1: tap(KeyEvent.KEYCODE_GRAVE); break;
                case 2: edit = true; selected = null; break;
                case 3: resetLayout(); break;
                case 4: ((Activity) getContext()).finish(); break;
            }
            invalidate();
        }).show();
    }

    // ---------- touch ----------
    private Btn hit(float x, float y) {
        for (int i = btns.size() - 1; i >= 0; i--) {
            Btn b = btns.get(i);
            if (visible(b) && b.r.contains(x, y)) return b;
        }
        return null;
    }

    private boolean editTouch(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                for (int i = 0; i < 4; i++) if (panel[i].contains(x, y)) {
                    if (i == 0 && selected != null) { selected.fd = Math.max(0.06f, selected.fd * 0.9f); place(selected); }
                    if (i == 1 && selected != null) { selected.fd = Math.min(0.5f, selected.fd * 1.1f); place(selected); }
                    if (i == 2) resetLayout();
                    if (i == 3) { saveLayout(); edit = false; selected = null; }
                    invalidate(); return true;
                }
                dragging = hit(x, y);
                if (dragging != null) {
                    selected = dragging;
                    dragDx = x - dragging.r.centerX(); dragDy = y - dragging.r.centerY();
                }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                if (dragging != null) {
                    dragging.fx = Math.min(1f, Math.max(0f, (x - dragDx) / getWidth()));
                    dragging.fy = Math.min(1f, Math.max(0f, (y - dragDy) / getHeight()));
                    place(dragging);
                }
                break;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                dragging = null; break;
        }
        invalidate();
        return true;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (edit) return editTouch(e);
        int a = e.getActionMasked(), idx = e.getActionIndex(), id = e.getPointerId(idx);
        float x = e.getX(idx), y = e.getY(idx);
        switch (a) {
            case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN: {
                Btn b = hit(x, y);
                if (b != null && b.ptr < 0) {
                    b.ptr = id;
                    if (b.act != A_NONE) action(b); else SDLActivity.onNativeKeyDown(b.key);
                    invalidate(); return true;
                }
                if (menuMode) break;
                if (x < getWidth() / 2f && stickPtr < 0) { stickPtr = id; sx = cx = x; sy = cy = y; }
                else if (x >= getWidth() / 2f && lookPtr < 0) { lookPtr = id; lastX = x; lastY = y; }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int pid = e.getPointerId(i);
                    if (pid == stickPtr) { cx = e.getX(i); cy = e.getY(i); updateDirs(); }
                    else if (pid == lookPtr) {
                        float nx = e.getX(i), ny = e.getY(i);
                        SDLActivity.onNativeMouse(0, MotionEvent.ACTION_MOVE, (nx - lastX) * 1.5f, (ny - lastY) * 1.5f, true);
                        lastX = nx; lastY = ny;
                    }
                }
                break;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_POINTER_UP: case MotionEvent.ACTION_CANCEL:
                for (Btn b : btns) if (b.ptr == id) {
                    b.ptr = -1;
                    if (b.act == A_NONE) SDLActivity.onNativeKeyUp(b.key);
                }
                if (id == stickPtr) { stickPtr = -1; cx = sx = 0.30f * getHeight(); cy = sy = 0.72f * getHeight(); updateDirs(); }
                if (id == lookPtr) lookPtr = -1;
                break;
        }
        invalidate();
        return true;
    }

    private void updateDirs() {
        float dz = getHeight() * 0.04f, dx = cx - sx, dy = cy - sy;
        boolean[] n = { dy < -dz, dx < -dz, dy > dz, dx > dz };
        for (int i = 0; i < 4; i++) if (n[i] != dir[i]) {
            dir[i] = n[i];
            if (n[i]) SDLActivity.onNativeKeyDown(DIR_KEYS[i]); else SDLActivity.onNativeKeyUp(DIR_KEYS[i]);
        }
    }

    // ---------- drawing ----------
    @Override protected void onDraw(Canvas c) {
        for (Btn b : btns) {
            if (!visible(b)) continue;
            boolean on = b.ptr >= 0 || (b.act == A_MAP && mapOn) || (b.act == A_WEAPONS && weaponsOn);
            p.setAlpha(on ? 255 : 150);
            c.drawBitmap(b.bmp, null, b.r, p);
            if (edit) {
                line.setColor(b == selected ? 0xFFFFDD00 : 0x99FFFFFF);
                c.drawRect(b.r, line);
            }
        }
        if (edit) {
            p.setAlpha(255);
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setTextAlign(Paint.Align.CENTER); t.setTextSize(getHeight() * 0.05f);
            for (int i = 0; i < 4; i++) {
                t.setColor(0xCC222222); c.drawRoundRect(panel[i], 16, 16, t);
                t.setColor(0xFFFFFFFF);
                c.drawText(PANEL_TXT[i], panel[i].centerX(), panel[i].centerY() + t.getTextSize() / 3, t);
            }
            t.setTextSize(getHeight() * 0.04f);
            c.drawText("Перетаскивайте кнопки. Нажмите кнопку, затем − / + для размера.", getWidth() / 2f, getHeight() * 0.5f, t);
            return;
        }
        if (menuMode) return;
        float base = getHeight() * 0.36f, knob = getHeight() * 0.16f;
        float kx = cx, ky = cy;
        float max = base * 0.4f, dx = kx - sx, dy = ky - sy, len = (float) Math.hypot(dx, dy);
        if (len > max) { kx = sx + dx / len * max; ky = sy + dy / len * max; }
        p.setAlpha(stickPtr >= 0 ? 200 : 90);
        c.drawBitmap(stickBase, null, new RectF(sx - base / 2, sy - base / 2, sx + base / 2, sy + base / 2), p);
        p.setAlpha(stickPtr >= 0 ? 255 : 120);
        c.drawBitmap(stickKnob, null, new RectF(kx - knob / 2, ky - knob / 2, kx + knob / 2, ky + knob / 2), p);
    }
}
