package com.doomtouch;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.system.Os;
import android.view.ViewGroup;
import java.io.*;
import java.util.*;
import org.libsdl.app.SDLActivity;

/** Runs unmodified GZDoom (as libgzdoom.so) inside SDL2's activity. */
public class GameActivity extends SDLActivity {
    private String iwadPath;   // copy of the chosen IWAD inside the app folder (always readable by the engine)

    @Override protected void onCreate(Bundle b) {
        try {
            // Send everything the engine prints (stdout/stderr) to a file, so startup errors can be read later
            // (Options -> Diagnostics shows its tail).
            java.io.FileOutputStream fos = new java.io.FileOutputStream(new File(getExternalFilesDir(null), "engine.log"), false);
            android.system.Os.dup2(fos.getFD(), android.system.OsConstants.STDOUT_FILENO);
            android.system.Os.dup2(fos.getFD(), android.system.OsConstants.STDERR_FILENO);
        } catch (Exception e) { e.printStackTrace(); }
        try {
            File home = getExternalFilesDir(null);
            File wads = new File(home, "wads");
            wads.mkdirs();
            copyAssets("", wads);                       // gzdoom.pk3, soundfonts, ... from app/src/main/assets
            String chosen = getIntent().getStringExtra("iwad");
            iwadPath = chosen;
            if (chosen != null) {
                File src = new File(chosen), dst = new File(wads, src.getName());
                if (src.isFile() && (!dst.exists() || dst.length() != src.length())) copyFile(src, dst);
                if (dst.isFile()) iwadPath = dst.getAbsolutePath();
            }
            // key binds for the touch buttons (GZDoom has no WASD / jump / crouch binds by default)
            try (FileWriter fw = new FileWriter(new File(home, "touch.cfg"))) {
                fw.write("bind w +forward\nbind s +back\nbind a +moveleft\nbind d +moveright\n"
                       + "bind x +jump\nbind c +crouch\nbind z weapprev\nbind v weapnext\n");
            }
            Os.setenv("DOOMWADDIR", wads.getAbsolutePath(), true); // engine finds gzdoom.pk3 here
            Os.setenv("HOME", home.getAbsolutePath(), true);
        } catch (Exception e) { e.printStackTrace(); }
        super.onCreate(b);
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src); OutputStream os = new FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
    }

    private void copyAssets(String path, File dst) throws IOException {
        AssetManager am = getAssets();
        String[] list = am.list(path);
        if (list == null || list.length == 0) {          // a file
            File out = new File(dst, path);
            if (out.exists()) return;
            out.getParentFile().mkdirs();
            try (InputStream in = am.open(path); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[1 << 16]; int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
        } else for (String f : list) copyAssets(path.isEmpty() ? f : path + "/" + f, dst);
    }

    @Override protected String[] getLibraries() {
        return new String[] { "c++_shared", "SDL2", "glib-2.0", "zmusic", "gzdoom" };
    }

    @Override protected String[] getArguments() {
        String home = getExternalFilesDir(null).getAbsolutePath();
        File saves = new File(LauncherActivity.root(), "saves");
        saves.mkdirs();
        String savedir = saves.canWrite() ? saves.getAbsolutePath() : home + "/saves";
        List<String> a = new ArrayList<>();
        a.add("-iwad"); a.add(iwadPath != null ? iwadPath : getIntent().getStringExtra("iwad"));
        a.add("-config"); a.add(home + "/gzdoom.ini");
        a.add("-savedir"); a.add(savedir);
        a.add("-stdout");
        a.add("+exec"); a.add(home + "/touch.cfg");
        a.add("+set"); a.add("vid_renderer"); a.add("0");
        String[] mods = getIntent().getStringArrayExtra("mods");
        if (mods != null && mods.length > 0) { a.add("-file"); a.addAll(Arrays.asList(mods)); }
        String extra = getIntent().getStringExtra("args");
        if (extra != null && !extra.trim().isEmpty()) a.addAll(Arrays.asList(extra.trim().split("\\s+")));
        return a.toArray(new String[0]);
    }

    @Override protected void onStart() {
        super.onStart();
        // Overlay is added on top of the SDL surface; it injects key/mouse events.
        addContentView(new TouchOverlay(this),
            new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }
}
