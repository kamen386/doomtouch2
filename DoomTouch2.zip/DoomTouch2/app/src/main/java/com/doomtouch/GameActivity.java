package com.doomtouch;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.system.Os;
import android.view.ViewGroup;
import java.io.*;
import org.libsdl.app.SDLActivity;

/** Runs unmodified GZDoom (as libgzdoom.so) inside SDL2's activity. */
public class GameActivity extends SDLActivity {
    @Override protected void onCreate(Bundle b) {
        try {
            File wads = new File(getExternalFilesDir(null), "wads");
            wads.mkdirs();
            copyAssets("", wads);                       // gzdoom.pk3, soundfonts, ... from app/src/main/assets
            Os.setenv("DOOMWADDIR", wads.getAbsolutePath(), true); // engine finds gzdoom.pk3 here
            Os.setenv("HOME", getExternalFilesDir(null).getAbsolutePath(), true);
        } catch (Exception e) { e.printStackTrace(); }
        super.onCreate(b);
    }

    private void copyAssets(String path, File dst) throws IOException {
        AssetManager am = getAssets();
        String[] list = am.list(path);
        if (list == null || list.length == 0) {          // a file
            File out = new File(dst, path);
            if (out.exists()) return;
            out.getParentFile().mkdirs();
            try (InputStream in = am.open(path); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[1 << 16]; int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
        } else for (String f : list) copyAssets(path.isEmpty() ? f : path + "/" + f, dst);
    }

    @Override protected String[] getLibraries() {
        return new String[] { "c++_shared", "SDL2", "zmusic", "gzdoom" };
    }

    @Override protected String[] getArguments() {
        String iwad = getIntent().getStringExtra("iwad");
        String home = getExternalFilesDir(null).getAbsolutePath();
        return new String[] { "-iwad", iwad, "+set", "vid_renderer", "0",
                              "-config", home + "/gzdoom.ini", "-savedir", home + "/saves" };
    }

    @Override protected void onStart() {
        super.onStart();
        // Overlay is added on top of the SDL surface; it injects key/mouse events.
        addContentView(new TouchOverlay(this),
            new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }
}
