#!/usr/bin/env bash
# Builds SDL2 + ZMusic + UNMODIFIED GZDoom for arm64-v8a and installs them into the app.
# Needs: git cmake ninja, Android NDK (ANDROID_NDK_HOME). Run from repo root.
set -euo pipefail

SDL_TAG=${SDL_TAG:-release-2.30.8}
ZMUSIC_TAG=${ZMUSIC_TAG:-1.1.14}
GZDOOM_TAG=${GZDOOM_TAG:-g4.13.1}     # change to the release you want; keep in sync with ZMUSIC_TAG
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME}"
ABI=arm64-v8a; API=26
TC="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake"
ROOT=$(pwd); WORK="$ROOT/native"; OUT="$ROOT/app/src/main"
mkdir -p "$WORK" "$OUT/jniLibs/$ABI" "$OUT/java/org/libsdl/app" "$OUT/assets"
cd "$WORK"

clone() { [ -d "$2" ] || git clone --depth 1 --branch "$3" "$1" "$2"; }
clone https://github.com/libsdl-org/SDL.git SDL "$SDL_TAG"
clone https://github.com/ZDoom/ZMusic.git ZMusic "$ZMUSIC_TAG"
clone https://github.com/ZDoom/gzdoom.git gzdoom "$GZDOOM_TAG"

# 1) SDL2 Java glue (SDLActivity etc.) -> app sources, untouched
cp SDL/android-project/app/src/main/java/org/libsdl/app/*.java "$OUT/java/org/libsdl/app/"

# 2) SDL2 shared lib
cmake -S SDL -B build-sdl -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release -DSDL_SHARED=ON -DSDL_STATIC=OFF
cmake --build build-sdl
cp build-sdl/libSDL2.so "$OUT/jniLibs/$ABI/"

# 3) ZMusic (static)
cmake -S ZMusic -B build-zmusic -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF \
  -DCMAKE_INSTALL_PREFIX="$WORK/zmusic-install"
cmake --build build-zmusic --target install

# 4) GZDoom host tools (zipdir, lemon, re2c, ...) so cross-compiling works
cmake -S gzdoom -B build-host -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build-host --target zipdir lemon re2c || cmake --build build-host --target zipdir lemon

# 5) Build-system only tweak: GZDoom is an executable, Android needs a shared lib
#    exporting SDL_main. Engine source files are NOT modified.
grep -n "add_executable( zdoom" gzdoom/src/CMakeLists.txt || { echo "!! add_executable(zdoom...) not found: adapt step 5 to this GZDoom tag"; exit 1; }
sed -i 's/add_executable( zdoom WIN32 MACOSX_BUNDLE/add_library( zdoom SHARED/' gzdoom/src/CMakeLists.txt

# 6) GZDoom for Android (GLES renderer, no Vulkan)
cmake -S gzdoom -B build-gzdoom -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release \
  -DIMPORT_EXECUTABLES="$WORK/build-host/ImportExecutables.cmake" \
  -DSDL2_DIR="$WORK/build-sdl" -DSDL2_INCLUDE_DIR="$WORK/SDL/include" \
  -DSDL2_LIBRARY="$WORK/build-sdl/libSDL2.so" \
  -DZMUSIC_INCLUDE_DIR="$WORK/zmusic-install/include" -DZMUSIC_LIBRARIES="$WORK/zmusic-install/lib/libzmusic.a" \
  -DNO_GTK=ON -DNO_OPENAL=OFF -DHAVE_VULKAN=OFF -DHAVE_GLES2=ON
cmake --build build-gzdoom
cp "$(find build-gzdoom -name 'libzdoom.so' | head -1)" "$OUT/jniLibs/$ABI/libgzdoom.so"
cp "$(find build-gzdoom -name 'gzdoom.pk3' | head -1)" "$OUT/assets/"
[ -d build-gzdoom/soundfonts ] && cp -r build-gzdoom/soundfonts "$OUT/assets/" || true
echo "Done. Now: ./gradlew assembleDebug"
