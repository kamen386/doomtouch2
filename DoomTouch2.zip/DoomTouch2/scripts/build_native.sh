#!/usr/bin/env bash
# Builds SDL2 + ZMusic + UNMODIFIED GZDoom for arm64-v8a and installs them into the app.
# Needs: git cmake ninja, Android NDK (ANDROID_NDK_HOME). Run from repo root.
set -euo pipefail

SDL_TAG=${SDL_TAG:-release-2.30.8}
ZMUSIC_TAG=${ZMUSIC_TAG:-1.1.12}
GZDOOM_TAG=${GZDOOM_TAG:-g4.12.2}     # keep in sync with ZMUSIC_TAG
GLIB_TAG=${GLIB_TAG:-2.80.5}
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME}"
ABI=arm64-v8a; API=28   # 28: bionic has iconv, which glib needs
TC="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake"
ROOT=$(pwd); WORK="$ROOT/native"; OUT="$ROOT/app/src/main"
mkdir -p "$WORK" "$OUT/jniLibs/$ABI" "$OUT/java/org/libsdl/app" "$OUT/assets"
cd "$WORK"

clone() { [ -d "$2" ] || git clone --depth 1 --branch "$3" "$1" "$2"; }
clone https://github.com/libsdl-org/SDL.git SDL "$SDL_TAG"
clone https://github.com/ZDoom/ZMusic.git ZMusic "$ZMUSIC_TAG"
clone https://github.com/ZDoom/gzdoom.git gzdoom "$GZDOOM_TAG"
clone https://gitlab.gnome.org/GNOME/glib.git glib "$GLIB_TAG"

# 1) SDL2 Java glue (SDLActivity etc.) -> app sources, untouched
cp SDL/android-project/app/src/main/java/org/libsdl/app/*.java "$OUT/java/org/libsdl/app/"

# 2) SDL2 shared lib
cmake -S SDL -B build-sdl -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release -DSDL_SHARED=ON -DSDL_STATIC=OFF
cmake --build build-sdl
cp build-sdl/libSDL2.so "$OUT/jniLibs/$ABI/"

# 2b) glib for Android. ZMusic bundles FluidSynth, which needs glib; Android has none.
sudo apt-get install -y patchelf >/dev/null
python3 -m pip install --user --break-system-packages meson >/dev/null
export PATH="$HOME/.local/bin:$PATH"
TOOLBIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
cat > android-cross.ini <<EOT
[binaries]
c = '$TOOLBIN/aarch64-linux-android$API-clang'
cpp = '$TOOLBIN/aarch64-linux-android$API-clang++'
ar = '$TOOLBIN/llvm-ar'
strip = '$TOOLBIN/llvm-strip'
pkg-config = 'pkg-config'
[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'
[properties]
needs_exe_wrapper = true
EOT
GLIB_PREFIX="$WORK/glib-install"
meson setup build-glib glib --cross-file android-cross.ini --prefix="$GLIB_PREFIX" --libdir=lib \
  --buildtype=release -Ddefault_library=shared \
  -Dlibffi:default_library=static -Dpcre2:default_library=static \
  -Dproxy-libintl:default_library=static -Dzlib:default_library=static \
  -Dtests=false -Dintrospection=disabled -Dnls=disabled -Dselinux=disabled -Dlibmount=disabled \
  -Dman-pages=disabled -Dsysprof=disabled -Dlibelf=disabled -Dglib_debug=disabled -Dxattr=false
meson compile -C build-glib
meson install -C build-glib
# Android can only load libNAME.so (no version suffix): rename real files and fix sonames IN the install dir
for f in $(find "$GLIB_PREFIX/lib" -maxdepth 1 -name 'lib*.so*' -type f); do
  base=$(basename "$f"); name="${base%%.so*}.so"
  if [ "$base" != "$name" ]; then cp -L --remove-destination "$f" "$GLIB_PREFIX/lib/$name"; fi
done
for f in "$GLIB_PREFIX"/lib/lib*.so; do
  [ -L "$f" ] && continue
  patchelf --set-soname "$(basename "$f")" "$f"
  for n in $(patchelf --print-needed "$f"); do
    case $n in lib*.so.*) patchelf --replace-needed "$n" "${n%%.so*}.so" "$f";; esac
  done
  cp -L "$f" "$OUT/jniLibs/$ABI/"
done
ls -la "$OUT/jniLibs/$ABI/"

# 3) ZMusic as a shared lib (loaded by the app before libgzdoom.so).
#    CMAKE_PLATFORM_NO_VERSIONED_SONAME: Android can only load libzmusic.so, not libzmusic.so.1
export PKG_CONFIG_LIBDIR="$GLIB_PREFIX/lib/pkgconfig"   # only the Android glib; never the host one
export PKG_CONFIG_PATH="$GLIB_PREFIX/lib/pkgconfig"
cmake -S ZMusic -B build-zmusic -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DANDROID_STL=c++_shared -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_SHARED_LIBS=ON -DCMAKE_PLATFORM_NO_VERSIONED_SONAME=ON \
  -DDYN_FLUIDSYNTH=ON -DDYN_SNDFILE=ON -DDYN_MPG123=ON \
  -DCMAKE_INSTALL_PREFIX="$WORK/zmusic-install"
cmake --build build-zmusic --target install
cp "$WORK/zmusic-install/lib/libzmusic.so" "$OUT/jniLibs/$ABI/"
cp "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so" "$OUT/jniLibs/$ABI/"

# 4) GZDoom host tools (zipdir, lemon, re2c, ...) so cross-compiling works
cmake -S gzdoom -B build-host -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build-host --target zipdir lemon re2c || cmake --build build-host --target zipdir lemon

# 5) Build-system only tweak: GZDoom is an executable, Android needs a shared lib
#    exporting SDL_main. Engine source files are NOT modified.
grep -n "add_executable( zdoom" gzdoom/src/CMakeLists.txt || { echo "!! add_executable(zdoom...) not found: adapt step 5 to this GZDoom tag"; exit 1; }
sed -i 's/add_executable( zdoom WIN32 MACOSX_BUNDLE/add_library( zdoom SHARED/' gzdoom/src/CMakeLists.txt

# 6) GZDoom for Android (GLES renderer, no Vulkan)
cmake -S gzdoom -B build-gzdoom -G Ninja -DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI=$ABI \
  -DANDROID_PLATFORM=android-$API -DANDROID_STL=c++_shared -DCMAKE_BUILD_TYPE=Release \
  -DIMPORT_EXECUTABLES="$WORK/build-host/ImportExecutables.cmake" \
  -DSDL2_DIR="$WORK/build-sdl" -DSDL2_INCLUDE_DIR="$WORK/SDL/include" \
  -DSDL2_LIBRARY="$WORK/build-sdl/libSDL2.so" \
  -DZMUSIC_INCLUDE_DIR="$WORK/zmusic-install/include" -DZMUSIC_LIBRARIES="$WORK/zmusic-install/lib/libzmusic.so" \
  -DNO_GTK=ON -DNO_OPENAL=OFF -DHAVE_VULKAN=OFF -DHAVE_GLES2=ON
cmake --build build-gzdoom
cp "$(find build-gzdoom -name 'libzdoom.so' | head -1)" "$OUT/jniLibs/$ABI/libgzdoom.so"
cp "$(find build-gzdoom -name 'gzdoom.pk3' | head -1)" "$OUT/assets/"
[ -d build-gzdoom/soundfonts ] && cp -r build-gzdoom/soundfonts "$OUT/assets/" || true
echo "Done. Now: ./gradlew assembleDebug"
