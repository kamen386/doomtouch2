#include <jni.h>
#include <stdio.h>

/* Make the engine's stdout/stderr unbuffered so its messages reach engine.log even if it exits abruptly. */
JNIEXPORT void JNICALL Java_com_doomtouch_GameActivity_unbuffer(JNIEnv *env, jclass cls)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
