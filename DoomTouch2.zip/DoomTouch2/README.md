# Doom Touch 2

New Android app: SDL2 Activity + GZDoom built from upstream sources (engine files unmodified)
+ own touch overlay that feeds ordinary keyboard/mouse events to the engine.

## Build
1. Put the project in a GitHub repo, run workflow **build-apk** (Actions tab), or locally:
   `export ANDROID_NDK_HOME=...; ./scripts/build_native.sh && gradle assembleDebug`
2. Download the APK (and `native.log` if the native step failed) from the workflow artifacts.
3. Change engine version: edit `GZDOOM_TAG` / `ZMUSIC_TAG` in `scripts/build_native.sh`.

## Run
Start the app, tap "Выбрать IWAD", choose doom2.wad / freedoom2.wad. Touch: left half = stick (WASD),
right half drag = look, buttons FIRE/USE/weapon. In GZDoom bind keys as default (Ctrl fire, Space use).

## Not verified yet (written without being able to compile)
- Step 5 in build_native.sh (executable -> shared lib) depends on the GZDoom tag's CMake layout.
- GZDoom `main` must become `SDL_main` (SDL_main.h does it if SDL_MAIN_HANDLED is not defined).
- GLES backend flags (`HAVE_GLES2`) differ between tags; check `native.log`.
Send `native.log` back and these get fixed one by one.
